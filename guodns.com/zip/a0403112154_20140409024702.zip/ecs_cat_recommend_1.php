<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_cat_recommend`;");
E_C("CREATE TABLE `ecs_cat_recommend` (
  `cat_id` smallint(5) NOT NULL,
  `recommend_type` tinyint(1) NOT NULL,
  PRIMARY KEY  (`cat_id`,`recommend_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `ecs_cat_recommend` values('1','3');");
E_D("replace into `ecs_cat_recommend` values('2','3');");
E_D("replace into `ecs_cat_recommend` values('3','3');");
E_D("replace into `ecs_cat_recommend` values('7','2');");
E_D("replace into `ecs_cat_recommend` values('11','3');");
E_D("replace into `ecs_cat_recommend` values('12','3');");
E_D("replace into `ecs_cat_recommend` values('13','3');");
E_D("replace into `ecs_cat_recommend` values('18','3');");
E_D("replace into `ecs_cat_recommend` values('21','3');");
E_D("replace into `ecs_cat_recommend` values('22','3');");
E_D("replace into `ecs_cat_recommend` values('23','1');");
E_D("replace into `ecs_cat_recommend` values('23','2');");
E_D("replace into `ecs_cat_recommend` values('24','1');");
E_D("replace into `ecs_cat_recommend` values('25','1');");
E_D("replace into `ecs_cat_recommend` values('29','2');");
E_D("replace into `ecs_cat_recommend` values('30','3');");

require("../../inc/footer.php");
?>