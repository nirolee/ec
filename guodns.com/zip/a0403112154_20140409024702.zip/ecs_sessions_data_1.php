<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `ecs_sessions_data`;");
E_C("CREATE TABLE `ecs_sessions_data` (
  `sesskey` varchar(32) character set utf8 collate utf8_bin NOT NULL default '',
  `expiry` int(10) unsigned NOT NULL default '0',
  `data` longtext NOT NULL,
  PRIMARY KEY  (`sesskey`),
  KEY `expiry` (`expiry`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `ecs_sessions_data` values('ac11c107c1713440d5d3c5577086478d','4171189805','a:8:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;s:9:\"region_id\";s:2:\"76\";s:11:\"region_name\";s:6:\"广州\";s:7:\"pin_yin\";s:9:\"guangzhou\";s:12:\"captcha_word\";s:16:\"MmU4Mjc0OTZjMA==\";s:13:\"captcha_login\";s:16:\"ZjVhMzRjNGI4ZA==\";}');");
E_D("replace into `ecs_sessions_data` values('60aaec644880d3278070c0b4bb991a8e','4294967295','a:8:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;s:9:\"region_id\";i:0;s:11:\"region_name\";s:9:\"全国站\";s:7:\"pin_yin\";s:5:\"china\";s:12:\"captcha_word\";s:16:\"MjFmMmFhNWYyYw==\";s:14:\"display_search\";s:4:\"grid\";}');");
E_D("replace into `ecs_sessions_data` values('57b636506734a13f5df619953b3b882c','4294967295','a:10:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;s:9:\"region_id\";s:2:\"52\";s:11:\"region_name\";s:6:\"北京\";s:7:\"pin_yin\";s:7:\"beijing\";s:13:\"captcha_login\";s:16:\"Yjg5Njk1MTViYg==\";s:9:\"last_time\";s:10:\"1391406048\";s:7:\"last_ip\";s:12:\"222.84.77.12\";s:12:\"captcha_word\";s:16:\"NTk1OTg5NzFlMQ==\";}');");
E_D("replace into `ecs_sessions_data` values('b61e7c3e852f5d248e037d70b009792b','4174243557','a:8:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;s:9:\"region_id\";s:2:\"85\";s:11:\"region_name\";s:6:\"茂名\";s:7:\"pin_yin\";s:1:\"m\";s:12:\"captcha_word\";s:16:\"YjBjYjBiNmY2Zg==\";s:13:\"captcha_login\";s:16:\"ODVmYzRlODA0Ng==\";}');");
E_D("replace into `ecs_sessions_data` values('98e4df74e9bed1f891e75781c4cc07aa','4294967295','a:9:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;s:9:\"last_time\";s:10:\"1391490574\";s:7:\"last_ip\";s:13:\"111.59.234.94\";s:12:\"captcha_word\";s:16:\"Y2ExZjQzY2E3NQ==\";s:9:\"region_id\";s:2:\"52\";s:11:\"region_name\";s:6:\"北京\";s:7:\"pin_yin\";s:7:\"beijing\";}');");
E_D("replace into `ecs_sessions_data` values('e7855e188787a647a6b3e54fafb02fe9','4294967295','a:8:{s:7:\"from_ad\";i:14;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;s:9:\"region_id\";i:0;s:11:\"region_name\";s:9:\"全国站\";s:7:\"pin_yin\";s:5:\"china\";s:12:\"captcha_word\";s:16:\"Yzc2MmU4YjUyMQ==\";s:14:\"display_search\";s:4:\"grid\";}');");
E_D("replace into `ecs_sessions_data` values('eb06ef94c03edc7753dfde47c4a8de98','4294967295','a:9:{s:7:\"from_ad\";i:149;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;s:9:\"region_id\";s:2:\"81\";s:11:\"region_name\";s:6:\"河源\";s:7:\"pin_yin\";s:1:\"h\";s:12:\"captcha_word\";s:16:\"NTRiYzEzNmIyZA==\";s:13:\"captcha_login\";s:16:\"ZWQ5OWZiYjhlMw==\";s:14:\"display_search\";s:4:\"grid\";}');");
E_D("replace into `ecs_sessions_data` values('e171ab4aba1219084f90f3f9a96e4762','2785936240','a:8:{s:7:\"from_ad\";i:2;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:1;s:9:\"region_id\";i:0;s:11:\"region_name\";s:9:\"全国站\";s:7:\"pin_yin\";s:1:\"d\";s:13:\"captcha_login\";s:16:\"MTQwYWZlNGIyYg==\";s:12:\"captcha_word\";s:16:\"Mzk1ODBhNjUwOQ==\";}');");
E_D("replace into `ecs_sessions_data` values('1fea93e20a4b44585f901cfbc194a03a','4294967295','a:8:{s:7:\"from_ad\";i:66;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;s:9:\"region_id\";i:0;s:11:\"region_name\";s:9:\"全国站\";s:7:\"pin_yin\";s:5:\"china\";s:12:\"captcha_word\";s:16:\"N2E1ZGQ4MzE4Ng==\";s:13:\"captcha_login\";s:16:\"YWI1ODg5OTg3MQ==\";}');");
E_D("replace into `ecs_sessions_data` values('3cffbf9dfcd517936e55d4bf0b248638','4179210559','a:9:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;s:9:\"region_id\";s:2:\"76\";s:11:\"region_name\";s:6:\"广州\";s:7:\"pin_yin\";s:9:\"guangzhou\";s:14:\"display_search\";s:4:\"grid\";s:12:\"captcha_word\";s:16:\"YThlZDY3NWU4Zg==\";s:9:\"flow_type\";i:0;}');");
E_D("replace into `ecs_sessions_data` values('63d40ddbe5c7fed4100b0e62fbc728fa','4179686196','a:8:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:1;s:9:\"region_id\";s:2:\"83\";s:11:\"region_name\";s:6:\"江门\";s:7:\"pin_yin\";s:1:\"j\";s:12:\"captcha_word\";s:16:\"YTc4YmFiYTlkYQ==\";s:13:\"captcha_login\";s:16:\"MWE4ZTY0OGM5ZQ==\";}');");
E_D("replace into `ecs_sessions_data` values('43db34058795a3ebcd71e4a4bf3c65c4','4294967295','a:9:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;s:9:\"region_id\";i:0;s:11:\"region_name\";s:9:\"全国站\";s:7:\"pin_yin\";s:5:\"china\";s:12:\"captcha_word\";s:16:\"ZTcxNWJiNGZkNQ==\";s:9:\"flow_type\";i:0;s:10:\"flow_order\";a:9:{s:14:\"extension_code\";s:0:\"\";s:11:\"shipping_id\";i:0;s:6:\"pay_id\";i:1;s:7:\"pack_id\";i:0;s:7:\"card_id\";i:0;s:5:\"bonus\";i:0;s:8:\"integral\";i:0;s:7:\"surplus\";i:0;s:8:\"bonus_id\";s:0:\"\";}}');");
E_D("replace into `ecs_sessions_data` values('e8284dc56541a7edcbd297e74b6658f0','4294967295','a:10:{s:7:\"from_ad\";i:0;s:7:\"referer\";s:6:\"本站\";s:10:\"login_fail\";i:0;s:9:\"region_id\";i:0;s:11:\"region_name\";s:9:\"全国站\";s:7:\"pin_yin\";s:5:\"china\";s:12:\"captcha_word\";s:16:\"YmU0YjVlN2JjOA==\";s:9:\"flow_type\";i:0;s:10:\"flow_order\";a:8:{s:14:\"extension_code\";s:0:\"\";s:11:\"shipping_id\";i:0;s:6:\"pay_id\";i:0;s:7:\"pack_id\";i:0;s:7:\"card_id\";i:0;s:5:\"bonus\";i:0;s:8:\"integral\";i:0;s:7:\"surplus\";i:0;}s:13:\"captcha_login\";s:16:\"ZTk1ZTA3MzBlZQ==\";}');");
E_D("replace into `ecs_sessions_data` values('e377fc2ee6ac8905f56b5cdb1754dc29','4294967295','a:4:{s:9:\"last_time\";i:1393912134;s:7:\"last_ip\";s:0:\"\";s:10:\"login_fail\";i:0;s:14:\"consignee_info\";a:14:{s:10:\"address_id\";i:0;s:9:\"consignee\";s:9:\"发挥好\";s:7:\"country\";i:1;s:8:\"province\";i:6;s:4:\"city\";i:84;s:8:\"district\";i:773;s:5:\"email\";s:0:\"\";s:7:\"address\";s:18:\"发挥好哈哈哈\";s:7:\"zipcode\";s:0:\"\";s:3:\"tel\";s:11:\"15013475862\";s:6:\"mobile\";s:0:\"\";s:13:\"sign_building\";s:0:\"\";s:9:\"best_time\";s:0:\"\";s:7:\"user_id\";s:1:\"2\";}}');");

require("../../inc/footer.php");
?>