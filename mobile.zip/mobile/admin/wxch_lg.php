<?php
define('IN_ECTOUCH', true);
error_reporting(0);
$wxch_lang['copyright'] = 'Powered by jiajuz.com';
$wxch_lang['cp_home'] = 'jiajuz.com';
$wxch_lang['kefu'] = '';
$wxch_lang['config'] = 'jiajuz.com设置';
?>